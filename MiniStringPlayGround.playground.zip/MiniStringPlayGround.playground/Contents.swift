import UIKit

func countHi(input: String){
    let chi = input.lowercased()
    let ss = chi.components(separatedBy: "hi")
    print("The string 'hi' appears \(ss.count-1) time(s)")
}
countHi(input: "ABChi")

func endOther(input: String, input2: String){
    let i1 = input.lowercased()
    let i2 = input2.lowercased()
    
    if i2.count > i1.count {
        if i2.suffix(i1.count) == i1 {
            print("true")
        }
    } else if i1.suffix(i2.count) == i2 {
        print("true")
    } else {print("false")}
    
    
}


endOther(input: "Hiabc", input2: "abc")




func sumNumber(input: String){
    var sumnum = 0
    
    let stringArray = input.components(separatedBy: CharacterSet.decimalDigits.inverted)
for item in stringArray {
    if let number = Int(item) {
        sumnum += number
        print("number: \(number)")
    }
   
}
     print(sumnum)
    
}


sumNumber(input: "7 11")

















